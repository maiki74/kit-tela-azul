@echo off
rem CMD - um clique para reaplicar o ajuste original - Windows 11
setlocal
set "PSModulePath="
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kit.ps1" -Modo Aplicar %*
exit /b %errorlevel%
