# PowerShell 5.1 - funcoes do kit - Windows 11 x64
Set-StrictMode -Version 2

function Get-KitFileHash {
    param([string]$Path)
    $sha=[Security.Cryptography.SHA256]::Create()
    $stream=$null
    try {
        $stream=[IO.File]::OpenRead($Path)
        return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()
    } finally { if($stream){$stream.Dispose()}; $sha.Dispose() }
}

function Get-GuidInText {
    param([string]$Text)
    $m = [regex]::Match($Text, '(?i)\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b')
    if (-not $m.Success) { throw 'Nao foi possivel identificar o plano de energia.' }
    return $m.Value.ToLowerInvariant()
}

function Get-IdleValues {
    param([string]$Text)
    $id = '5d76a2ca-e8c0-402f-a133-2158492d58ad'
    $start = $Text.IndexOf($id, [StringComparison]::OrdinalIgnoreCase)
    if ($start -lt 0) { throw 'O ajuste IDLEDISABLE nao foi encontrado.' }
    $part = $Text.Substring($start)
    $next = [regex]::Match($part.Substring($id.Length), '(?i)[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}')
    if ($next.Success) { $part = $part.Substring(0, $id.Length + $next.Index) }
    $values = [regex]::Matches($part, '(?i)0x([0-9a-f]{8})')
    if ($values.Count -ne 2) { throw 'Nao foi possivel ler os valores AC/DC de IDLEDISABLE.' }
    return [pscustomobject]@{ AC = [Convert]::ToInt32($values[0].Groups[1].Value,16); DC = [Convert]::ToInt32($values[1].Groups[1].Value,16) }
}

function Get-SfcStatus {
    param([string]$Text)
    $plain = [regex]::Replace($Text.Normalize([Text.NormalizationForm]::FormD), '\p{Mn}', '').ToLowerInvariant()
    if ($plain -match 'nao encontrou nenhuma violacao de integridade|did not find any integrity violations') { return 'Limpo' }
    if ($plain -match 'reparou com exito|successfully repaired') { return 'Reparado' }
    if ($plain -match 'unable to fix|could not repair|nao.*reparar|encontrou violacoes de integridade') { return 'Problema' }
    return 'Indeterminado'
}

function Assert-KitIntegrity {
    param([string]$Root)
    $base = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'
    $manifest = Get-Content -LiteralPath (Join-Path $Root 'manifesto.json') -Raw | ConvertFrom-Json
    if ($manifest.schema -ne 1 -or @($manifest.files).Count -lt 5) { throw 'Manifesto do kit invalido.' }
    foreach ($entry in $manifest.files) {
        $rel = [string]$entry.path
        if ([IO.Path]::IsPathRooted($rel) -or $rel -match '(^|[\\/])\.\.([\\/]|$)') { throw 'Caminho invalido no manifesto.' }
        $path = [IO.Path]::GetFullPath((Join-Path $Root $rel))
        if (-not $path.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)) { throw 'Arquivo fora da pasta do kit.' }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Arquivo do kit ausente: $rel. Extraia o ZIP inteiro." }
        if ((Get-KitFileHash $path) -ne $entry.sha256) { throw "Arquivo alterado/incompleto: $rel. Extraia novamente o ZIP original." }
    }
    return $manifest
}

function Get-RegistryRollbackActions {
    param([object[]]$Before, [object[]]$Current)
    $expected = @{ CrashDumpEnabled=7; AlwaysKeepMemoryDump=1 }
    foreach ($old in $Before) {
        if (-not $expected.ContainsKey([string]$old.Name)) { throw 'Nome de registro fora do escopo do kit.' }
        $now = @($Current | Where-Object Name -eq $old.Name)
        if ($now.Count -ne 1) { throw 'Leitura do registro incompleta.' }
        if (-not $now[0].Exists -or [long]$now[0].Value -ne $expected[$old.Name]) {
            [pscustomobject]@{ Action='Preservar'; Entry=$old }
        } elseif ($old.Exists) {
            [pscustomobject]@{ Action='Restaurar'; Entry=$old }
        } else {
            [pscustomobject]@{ Action='Remover'; Entry=$old }
        }
    }
}

function Test-ShouldRestoreScheme {
    param([string]$Current, [string]$Owned)
    return (-not [string]::IsNullOrWhiteSpace($Owned) -and $Current -eq $Owned)
}

function Read-NativeOutput {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return '' }
    $bytes = [IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -eq 0) { return '' }
    $sample = $bytes | Select-Object -First 256
    if (@($sample | Where-Object { $_ -eq 0 }).Count -gt 12 -or ($bytes.Length -gt 1 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254)) {
        return [Text.Encoding]::Unicode.GetString($bytes).TrimStart([char]0xfeff)
    }
    return [Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xfeff)
}
