@echo off
rem CMD - desfazer somente as configuracoes aplicadas pelo kit
setlocal
set "PSModulePath="
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kit.ps1" -Modo Desfazer %*
exit /b %errorlevel%
