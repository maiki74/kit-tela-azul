@echo off
rem Limita a RTX 3050 (clock 1800 MHz, energia 98 W) para evitar tela preta em jogos.
rem Cria a tarefa "Limite GPU" que reaplica em todo login. Use "5-LIMITE-GPU.cmd desfazer" para remover.
setlocal
fltmc >nul 2>&1 || (powershell -NoProfile -Command "Start-Process -Verb RunAs -FilePath '%~f0' -ArgumentList '%*'" & exit /b)
set "SMI=%SystemRoot%\System32\nvidia-smi.exe"
if /i "%~1"=="desfazer" (
  schtasks /delete /f /tn "Limite GPU"
  "%SMI%" -rgc
  "%SMI%" -pl 115
  echo Limite removido.
  pause & exit /b
)
schtasks /create /f /tn "Limite GPU" /sc onlogon /rl highest /tr "cmd.exe /c %SMI% -pl 98 & %SMI% -lgc 210,1800"
"%SMI%" -pl 98
"%SMI%" -lgc 210,1800
echo.
echo Pronto: GPU limitada a 1800 MHz e 98 W, reaplicado em todo login.
pause
