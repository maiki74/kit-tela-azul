@echo off
rem CMD - verificar e reparar somente os arquivos do Windows
setlocal
set "PSModulePath="
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kit.ps1" -Modo Reparar %*
exit /b %errorlevel%
