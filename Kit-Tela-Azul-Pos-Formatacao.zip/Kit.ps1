# PowerShell 5.1 - Kit Tela Azul Maiki - Windows 11 x64
[CmdletBinding()]
param(
    [ValidateSet('Aplicar','Verificar','Desfazer','Reparar')][string]$Modo='Aplicar',
    [switch]$Simular,
    [switch]$SemPausa,
    [switch]$SomenteFuncoes
)
Set-StrictMode -Version 2
$ErrorActionPreference='Stop'
$root=$PSScriptRoot
. (Join-Path $root 'Kit.Core.ps1')
$script:LogPath=$null
$script:Forwarded=$false
$script:State=$null
$script:StatePath=$null
$script:RunDir=$null
$script:CrashKey='HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl'
$script:Group='54533251-82be-4824-96c1-47b60b740d00'
$script:Idle='5d76a2ca-e8c0-402f-a133-2158492d58ad'

function Write-KitLog {
    param([string]$Text)
    Write-Host $Text
    if ($script:LogPath) { Add-Content -LiteralPath $script:LogPath -Value ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Text) -Encoding UTF8 }
}

function Invoke-KitNative {
    param([string]$Exe,[string[]]$ArgumentList,[int[]]$Accepted=@(0))
    $saved=$ErrorActionPreference
    try { $ErrorActionPreference='Continue'; $lines=@(& $Exe @ArgumentList 2>&1); $code=$LASTEXITCODE }
    finally { $ErrorActionPreference=$saved }
    if ($code -notin $Accepted) { throw ('Falha em {0} {1}; codigo {2}: {3}' -f $Exe,($ArgumentList -join ' '),$code,($lines -join ' ')) }
    return ($lines -join [Environment]::NewLine)
}

function Get-ActiveScheme {
    return Get-GuidInText (Invoke-KitNative 'powercfg.exe' @('/getactivescheme'))
}

function Get-PlanIdle {
    param([string]$Guid)
    return Get-IdleValues (Invoke-KitNative 'powercfg.exe' @('/qh',$Guid,$script:Group))
}

function Test-SchemeExists {
    param([string]$Guid)
    return ((Invoke-KitNative 'powercfg.exe' @('/list')) -match [regex]::Escape($Guid))
}

function Read-CrashValues {
    $key=Get-Item -LiteralPath $script:CrashKey
    foreach ($name in @('CrashDumpEnabled','AlwaysKeepMemoryDump')) {
        $exists=$key.GetValueNames() -contains $name
        $value=$null; $kind=$null
        if ($exists) { $value=$key.GetValue($name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames); $kind=$key.GetValueKind($name).ToString() }
        [pscustomobject]@{ Name=$name; Exists=$exists; Value=$value; Kind=$kind }
    }
}

function Save-KitState {
    $json=$script:State | ConvertTo-Json -Depth 10
    $temp=$script:StatePath+'.tmp'
    $json | Set-Content -LiteralPath $temp -Encoding UTF8
    Move-Item -LiteralPath $temp -Destination $script:StatePath -Force
}

function Initialize-KitState {
    $machine=[string](Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
    if ($machine -notmatch '^[0-9a-fA-F-]{32,40}$') { throw 'Identificador desta instalacao do Windows invalido.' }
    $script:RunDir=Join-Path (Join-Path $root 'Execucoes') $machine
    New-Item -ItemType Directory -Path $script:RunDir -Force | Out-Null
    $script:StatePath=Join-Path $script:RunDir 'estado.json'
    $script:LogPath=Join-Path $script:RunDir ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-'+$Modo+'.log')
    if (Test-Path -LiteralPath $script:StatePath) {
        $script:State=Get-Content -LiteralPath $script:StatePath -Raw | ConvertFrom-Json
        if ($script:State.Schema -ne 1 -or $script:State.MachineId -ne $machine) { throw 'Backup nao pertence a esta instalacao.' }
        if ($Modo -eq 'Aplicar' -and $script:State.Status -eq 'Configuracoes desfeitas') {
            Copy-Item -LiteralPath $script:StatePath -Destination (Join-Path $script:RunDir ((Get-Date -Format 'yyyyMMdd-HHmmss-fff')+'-backup-anterior.json'))
            $script:State.BeforeScheme=Get-ActiveScheme
            $script:State.BeforeRegistry=@(Read-CrashValues)
            $script:State.Created=Get-Date -Format o
            Save-KitState
        }
    } elseif ($Modo -eq 'Desfazer') {
        throw 'Nenhuma aplicacao do kit foi registrada nesta instalacao do Windows.'
    } else {
        $script:State=[pscustomobject]@{
            Schema=1; MachineId=$machine; Created=(Get-Date -Format o)
            BeforeScheme=(Get-ActiveScheme); BeforeRegistry=@(Read-CrashValues)
            OwnedScheme=$null; ConfigurationApplied=$false; RepairStatus='Nao executado'; Status='Backup salvo'
        }
        Save-KitState
    }
    Write-KitLog ('Logs e backup: '+$script:RunDir)
}

function Assert-ThisHardware {
    $board=Get-CimInstance Win32_BaseBoard
    $cpu=Get-CimInstance Win32_Processor | Select-Object -First 1
    $os=Get-CimInstance Win32_OperatingSystem
    if ($board.Product.Trim() -ne 'B550MH 3.0' -or $cpu.Name -notmatch 'Ryzen 5 3600' -or [int]$os.BuildNumber -lt 22000 -or -not [Environment]::Is64BitOperatingSystem) {
        throw 'Kit destinado ao Ryzen 5 3600 / BIOSTAR B550MH 3.0 com Windows 11 x64. Nenhuma configuracao sera aplicada em outro hardware.'
    }
}

function Invoke-LongNative {
    param([string]$Name,[string]$Exe,[string[]]$ArgumentList,[int[]]$Accepted=@(0,3010))
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    $raw=Join-Path $script:RunDir ($stamp+'-'+$Name+'-raw.txt')
    $err=Join-Path $script:RunDir ($stamp+'-'+$Name+'-stderr.txt')
    Write-KitLog ('Executando '+$Name+'. Nao desligue o PC. O Windows Update pode obter componentes de reparo.')
    $watch=[Diagnostics.Stopwatch]::StartNew()
    # Preserva bytes nativos: SFC escreve UTF-16, sem passar pelo decodificador do PowerShell.
    $p=$null; $stdoutFile=$null; $stderrFile=$null
    try {
        $info=New-Object Diagnostics.ProcessStartInfo
        $info.FileName=$Exe
        $info.Arguments=$ArgumentList -join ' '
        $info.UseShellExecute=$false
        $info.CreateNoWindow=$true
        $info.RedirectStandardOutput=$true
        $info.RedirectStandardError=$true
        $p=New-Object Diagnostics.Process
        $p.StartInfo=$info
        if (-not $p.Start()) { throw ('Nao foi possivel iniciar '+$Name) }
        $stdoutFile=[IO.File]::Create($raw)
        $stderrFile=[IO.File]::Create($err)
        $stdoutTask=$p.StandardOutput.BaseStream.CopyToAsync($stdoutFile)
        $stderrTask=$p.StandardError.BaseStream.CopyToAsync($stderrFile)
        $lastReport=0
        while (-not $p.WaitForExit(1000)) {
            if ($watch.Elapsed.TotalSeconds-$lastReport -ge 20) {
                Write-KitLog ('  '+$Name+' continua em execucao: '+[math]::Round($watch.Elapsed.TotalMinutes,1)+' min.')
                $lastReport=$watch.Elapsed.TotalSeconds
            }
        }
        $p.WaitForExit()
        $null=$stdoutTask.GetAwaiter().GetResult()
        $null=$stderrTask.GetAwaiter().GetResult()
        $code=$p.ExitCode
    } finally {
        if ($stdoutFile) { $stdoutFile.Dispose() }
        if ($stderrFile) { $stderrFile.Dispose() }
        if ($p) { $p.Dispose() }
    }
    $text=Read-NativeOutput $raw
    $clean=Join-Path $script:RunDir ($stamp+'-'+$Name+'.txt')
    $text | Set-Content -LiteralPath $clean -Encoding UTF8
    Write-KitLog ($Name+' terminou com codigo '+$code+'. Log: '+$clean)
    if ($code -notin $Accepted) { throw ($Name+' falhou. Leia '+$clean+' e '+$err) }
    return [pscustomobject]@{ Code=$code; Text=$text; Log=$clean }
}

function Invoke-WindowsRepair {
    $sfc=Join-Path $env:SystemRoot 'System32\sfc.exe'
    $dism=Join-Path $env:SystemRoot 'System32\dism.exe'
    $first=Invoke-LongNative 'SFC-verificacao-inicial' $sfc @('/verifyonly') @(0,1)
    if ((Get-SfcStatus $first.Text) -eq 'Limpo') {
        $script:State.RepairStatus='Verificacao limpa; reparo desnecessario'
        Save-KitState
        Write-KitLog 'SFC confirmou que nao ha violacoes de integridade. Nao e necessario reparar.'
        return
    }
    $script:State.RepairStatus='Reparo em andamento'; Save-KitState
    $dismResult=Invoke-LongNative 'DISM-reparo' $dism @('/Online','/Cleanup-Image','/RestoreHealth','/NoRestart','/English')
    $null=Invoke-LongNative 'SFC-reparo' $sfc @('/scannow')
    $last=Invoke-LongNative 'SFC-verificacao-final' $sfc @('/verifyonly')
    if ((Get-SfcStatus $last.Text) -ne 'Limpo') {
        $script:State.RepairStatus='Nao foi possivel confirmar integridade limpa'; Save-KitState
        throw ('A verificacao final nao confirmou integridade limpa. Consulte '+$last.Log)
    }
    $script:State.RepairStatus='Reparo concluido; verificacao final limpa'
    Save-KitState
    if ($dismResult.Code -eq 3010) { Write-KitLog 'O DISM indicou que e necessario reiniciar manualmente.' }
}

function Set-KitConfiguration {
    if ($script:State.OwnedScheme -and -not (Test-SchemeExists $script:State.OwnedScheme)) { $script:State.OwnedScheme=$null }
    if (-not $script:State.OwnedScheme) {
        $script:State.OwnedScheme=[guid]::NewGuid().ToString()
        Save-KitState
        $null=Invoke-KitNative 'powercfg.exe' @('/duplicatescheme',(Get-ActiveScheme),$script:State.OwnedScheme)
    }
    $guid=$script:State.OwnedScheme
    $null=Invoke-KitNative 'powercfg.exe' @('/changename',$guid,'Kit Maiki - virtualizacao com idle bloqueado')
    $null=Invoke-KitNative 'powercfg.exe' @('/setacvalueindex',$guid,$script:Group,$script:Idle,'1')
    if ((Get-PlanIdle $guid).AC -ne 1) { throw 'O Windows nao confirmou IDLEDISABLE=1.' }
    $null=Invoke-KitNative 'powercfg.exe' @('/setactive',$guid)
    if ((Get-ActiveScheme) -ne $guid) { throw 'O plano do kit nao ficou ativo.' }
    foreach ($entry in @(@('CrashDumpEnabled',7),@('AlwaysKeepMemoryDump',1))) {
        New-ItemProperty -LiteralPath $script:CrashKey -Name $entry[0] -Value $entry[1] -PropertyType DWord -Force | Out-Null
    }
    $values=@(Read-CrashValues)
    if (($values | Where-Object Name -eq 'CrashDumpEnabled').Value -ne 7 -or ($values | Where-Object Name -eq 'AlwaysKeepMemoryDump').Value -ne 1) { throw 'Falha ao verificar a configuracao dos dumps.' }
    $script:State.ConfigurationApplied=$true
    $script:State.Status='Configuracao aplicada e conferida'; Save-KitState
    Write-KitLog 'Confirmado: IDLEDISABLE AC=1; despejo automatico=7; preservar dump=1.'
    Write-KitLog 'Virtualizacao, hipervisor, BIOS, RAM e drivers nao foram alterados.'
}

function Undo-KitConfiguration {
    $owned=[string]$script:State.OwnedScheme
    $current=Get-ActiveScheme
    if (Test-ShouldRestoreScheme $current $owned) {
        if (-not (Test-SchemeExists $script:State.BeforeScheme)) { throw 'O plano anterior foi removido por outro programa. Nao vou escolher outro plano nem excluir o ativo.' }
        $null=Invoke-KitNative 'powercfg.exe' @('/setactive',$script:State.BeforeScheme)
        if ((Get-ActiveScheme) -ne $script:State.BeforeScheme) { throw 'Nao foi possivel voltar ao plano anterior.' }
    } else { Write-KitLog 'O plano ativo foi escolhido depois do kit; ele sera preservado.' }
    if ($owned -and (Test-SchemeExists $owned) -and (Get-ActiveScheme) -ne $owned) {
        $description=Invoke-KitNative 'powercfg.exe' @('/list')
        $line=@($description -split '\r?\n' | Where-Object { $_ -match [regex]::Escape($owned) }) -join ''
        if ($line -notmatch 'Kit Maiki') { throw 'O nome do plano mudou. Ele foi preservado para evitar remover configuracao de outro programa.' }
        $null=Invoke-KitNative 'powercfg.exe' @('/delete',$owned)
    }
    $actions=@(Get-RegistryRollbackActions @($script:State.BeforeRegistry) @(Read-CrashValues))
    foreach ($action in $actions) {
        $old=$action.Entry
        switch ($action.Action) {
            'Restaurar' { New-ItemProperty -LiteralPath $script:CrashKey -Name $old.Name -Value $old.Value -PropertyType $old.Kind -Force | Out-Null }
            'Remover' { Remove-ItemProperty -LiteralPath $script:CrashKey -Name $old.Name }
            'Preservar' { Write-KitLog ('Valor alterado depois do kit, preservado: '+$old.Name) }
        }
    }
    $script:State.OwnedScheme=$null
    $script:State.ConfigurationApplied=$false
    $script:State.Status='Configuracoes desfeitas'; Save-KitState
    Write-KitLog 'Configuracoes desfeitas. Reparos nativos de arquivos DISM/SFC nao sao desfeitos.'
}

if ($SomenteFuncoes) { return }
$exitCode=0
try {
    $null=Assert-KitIntegrity $root
    Write-Host 'KIT TELA AZUL MAIKI - Windows 11 / Ryzen 5 3600 / B550MH 3.0'
    Write-Host 'Repete IDLEDISABLE=1 na tomada e verifica/repara o Windows. Pode elevar consumo e temperatura em repouso.'
    Write-Host 'Nao desliga virtualizacao nem hipervisor. Nao atualiza BIOS, instala drivers ou reinicia sozinho.'
    if ($Modo -eq 'Verificar') {
        $plan=Get-ActiveScheme; $idle=Get-PlanIdle $plan
        Write-Host ('Integridade do kit: OK. Plano ativo: '+$plan)
        Write-Host ('IDLEDISABLE AC='+$idle.AC+'; DC='+$idle.DC)
        Write-Host ('Hipervisor ativo: '+(Get-CimInstance Win32_ComputerSystem).HypervisorPresent)
        Read-CrashValues | Format-Table Name,Exists,Value -AutoSize | Out-Host
    } else {
        Assert-ThisHardware
        if ($Simular) {
            Write-Host ('SIMULACAO '+$Modo+': nenhuma configuracao sera alterada; nenhum reparo sera executado.')
            if ($Modo -eq 'Aplicar') {
                Write-Host 'Salvar backup separado por instalacao do Windows; duplicar plano ativo; AC IDLEDISABLE=1; ativar copia; dumps=7/1; verificar SFC; reparar somente se necessario.'
            }
        } else {
            $admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
            if (-not $admin) {
                $script:Forwarded=$true
                $hostExe=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
                $argsLine='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Modo '+$Modo
                $child=Start-Process -FilePath $hostExe -ArgumentList $argsLine -Verb RunAs -WindowStyle Normal -Wait -PassThru
                exit $child.ExitCode
            }
            Initialize-KitState
            switch ($Modo) {
                'Aplicar' { Set-KitConfiguration; Invoke-WindowsRepair; $script:State.Status='Aplicacao concluida'; Save-KitState }
                'Reparar' { Invoke-WindowsRepair }
                'Desfazer' { Undo-KitConfiguration }
            }
            Write-KitLog ('CONCLUIDO: '+$Modo+'. Salve o trabalho e reinicie manualmente quando for conveniente.')
            Write-KitLog 'Se o hipervisor estava desligado na BIOS, este kit nao o liga. O estado precisa ser conferido apos o boot.'
        }
    }
} catch {
    $exitCode=1
    Write-KitLog ('FALHA: '+$_.Exception.Message)
    if ($script:State -and $script:StatePath) {
        try { $script:State.Status='Parcial ou falha: '+$_.Exception.Message; Save-KitState } catch { Write-Host 'Falha adicional ao registrar estado. Preserve a pasta do kit.' }
    }
    Write-Host 'Nao considere o kit aplicado por completo. Preserve o log; o botao DESFAZER restaura as configuracoes registradas.'
} finally {
    if (-not $SemPausa -and -not $script:Forwarded) { $null=Read-Host 'Pressione Enter para fechar' }
}
exit $exitCode
