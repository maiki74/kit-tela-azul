@echo off
rem CMD - conferir kit e estado do Windows sem alterar configuracoes
setlocal
set "PSModulePath="
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kit.ps1" -Modo Verificar %*
exit /b %errorlevel%
